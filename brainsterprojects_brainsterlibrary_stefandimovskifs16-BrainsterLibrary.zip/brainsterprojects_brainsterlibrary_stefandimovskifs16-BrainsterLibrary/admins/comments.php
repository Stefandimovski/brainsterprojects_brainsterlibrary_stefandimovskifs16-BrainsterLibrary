<?php
include 'db.php';


// Read all comments
$sql = "SELECT comments.*, users.username, books.title AS book_title FROM comments 
        JOIN users ON comments.user_id = users.id
        JOIN books ON comments.book_id = books.id
        -- WHERE comments.deleted_at = FALSE
        ";
$result = $conn->query($sql);

// Approve comment
if (isset($_POST['approve'])) {
    $id = $_POST['id'];
    $sql = "UPDATE comments SET approved=TRUE WHERE id=$id";
    if ($conn->query($sql) === TRUE) {
        echo "Comment approved successfully";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}

// Delete comment
if (isset($_POST['delete'])) {
    $id = $_POST['id'];
    $sql = "UPDATE comments SET deleted_at=TRUE WHERE id=$id";
    if ($conn->query($sql) === TRUE) {
        echo "Comment deleted successfully";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}
?>

<!DOCTYPE html>
<html>

<head>
    <title>Comments</title>
    <link rel="stylesheet" type="text/css" href="style.css">
</head>

<body>
    <a class="btn" href="index.php">Back</a>

    <h1>Comments</h1>


    <table>
        <thead>
            <tr>
                <th>ID</th>
                <th>Book</th>
                <th>User</th>
                <th>Content</th>
                <th>Approved</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php while ($row = $result->fetch_assoc()) : ?>
                <tr>
                    <td><?php echo $row['id']; ?></td>
                    <td><?php echo $row['book_title']; ?></td>
                    <td><?php echo $row['username']; ?></td>
                    <td><?php echo $row['comment']; ?></td>
                    <td><?php echo $row['approved'] ? 'Yes' : 'No'; ?></td>
                    <td>
                        <form method="POST" action="">
                            <input type="hidden" name="id" value="<?php echo $row['id']; ?>">
                            <button type="submit" name="approve">Approve</button>
                            <button type="submit" name="delete">Delete</button>
                        </form>
                    </td>
                </tr>
            <?php endwhile; ?>
        </tbody>
    </table>
</body>

</html>