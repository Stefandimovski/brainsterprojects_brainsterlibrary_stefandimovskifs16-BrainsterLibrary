<?php
include 'db.php';

$sql = "SELECT * FROM authors WHERE deleted_at IS NULL";
$result = mysqli_query($conn, $sql);

$authors = [];
while($row = mysqli_fetch_assoc($result)) {
    $authors[] = $row;
}

echo json_encode($authors);
?>
