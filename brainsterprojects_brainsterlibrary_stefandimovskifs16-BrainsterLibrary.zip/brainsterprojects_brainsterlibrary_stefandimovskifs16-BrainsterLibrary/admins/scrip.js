document.addEventListener('DOMContentLoaded', function() {
    fetchCategories();

    document.getElementById('createCategoryForm').addEventListener('submit', function(e) {
        e.preventDefault();
        createCategory();
    });
});

function fetchCategories() {
    fetch('read_categories.php')
        .then(response => response.json())
        .then(data => {
            const categoriesTableBody = document.getElementById('categoriesTable').querySelector('tbody');
            categoriesTableBody.innerHTML = '';
            data.forEach(category => {
                const row = document.createElement('tr');
                row.innerHTML = `
                    <td>${category.id}</td>
                    <td>${category.title}</td>
                    <td>
                        <button onclick="editCategory(${category.id}, '${category.title}')">Edit</button>
                        <button onclick="deleteCategory(${category.id})">Delete</button>
                    </td>
                `;
                categoriesTableBody.appendChild(row);
            });
        });
}

function createCategory() {
    const title = document.getElementById('title').value;
    const formData = new FormData();
    formData.append('title', title);

    fetch('create_category.php', {
        method: 'POST',
        body: formData
    })
    .then(response => response.text())
    .then(data => {
        alert(data);
        fetchCategories();
    });
}

function editCategory(id, title) {
    const newTitle = prompt('Edit Category Title:', title);
    if (newTitle !== null) {
        const formData = new FormData();
        formData.append('id', id);
        formData.append('title', newTitle);

        fetch('update_category.php', {
            method: 'POST',
            body: formData
        })
        .then(response => response.text())
        .then(data => {
            alert(data);
            fetchCategories();
        });
    }
}

function deleteCategory(id) {
    if (confirm('Are you sure you want to delete this category?')) {
        const formData = new FormData();
        formData.append('id', id);

        fetch('delete_category.php', {
            method: 'POST',
            body: formData
        })
        .then(response => response.text())
        .then(data => {
            alert(data);
            fetchCategories();
        });
    }
}
