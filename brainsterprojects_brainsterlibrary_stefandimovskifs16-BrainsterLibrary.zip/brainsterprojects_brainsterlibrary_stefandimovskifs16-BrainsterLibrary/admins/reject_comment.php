<?php
include 'db.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $id = $_POST['id'];

    $sql = "UPDATE comments SET approved=FALSE WHERE id=$id";
    if (mysqli_query($conn, $sql)) {
        echo "Comment rejected successfully";
    } else {
        echo "Error: " . $sql . "<br>" . mysqli_error($conn);
    }
}
?>
