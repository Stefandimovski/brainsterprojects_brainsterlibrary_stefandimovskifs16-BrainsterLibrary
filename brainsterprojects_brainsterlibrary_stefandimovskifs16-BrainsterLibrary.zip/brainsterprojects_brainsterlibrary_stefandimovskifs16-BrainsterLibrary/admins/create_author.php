<?php
include 'db.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $first_name = $_POST['first_name'];
    $last_name = $_POST['last_name'];
    $biography = $_POST['biography'];

    if (strlen($biography) < 20) {
        echo "Biography must be at least 20 characters long.";
    } else {
        $sql = "INSERT INTO authors (first_name, last_name, biography) VALUES ('$first_name', '$last_name', '$biography')";
        if (mysqli_query($conn, $sql)) {
            echo "New author created successfully";
        } else {
            echo "Error: " . $sql . "<br>" . mysqli_error($conn);
        }
    }
}
?>
