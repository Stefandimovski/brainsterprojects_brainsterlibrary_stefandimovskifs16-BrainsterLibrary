<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    echo "You need to be logged in to leave a comment.";
    exit;
}

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "brainster_library";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$user_id = $_SESSION['user_id'];
$book_id = $_POST['book_id'];
$comment = $_POST['comment'];

$sql = "INSERT INTO comments (user_id, book_id, comment, approved) VALUES (?, ?, ?, 0)";
$stmt = $conn->prepare($sql);
$stmt->bind_param("iis", $user_id, $book_id, $comment);

if ($stmt->execute()) {
    echo "Comment submitted for approval.";
} else {
    echo "Error: " . $stmt->error;
}

$stmt->close();
$conn->close();
