document.addEventListener('DOMContentLoaded', function() {
    fetchAuthors();
    fetchBooks();
    fetchCategories();

    document.getElementById('createAuthorForm').addEventListener('submit', function(e) {
        e.preventDefault();
        createAuthor();
    });

    document.getElementById('createBookForm').addEventListener('submit', function(e) {
        e.preventDefault();
        createBook();
    });
});

function fetchAuthors() {
    fetch('read_authors.php')
        .then(response => response.json())
        .then(data => {
            const authorsTableBody = document.getElementById('authorsTable').querySelector('tbody');
            const authorSelect = document.getElementById('author_id');
            authorsTableBody.innerHTML = '';
            authorSelect.innerHTML = '';
            data.forEach(author => {
                const row = document.createElement('tr');
                row.innerHTML = `
                    <td>${author.id}</td>
                    <td>${author.first_name}</td>
                    <td>${author.last_name}</td>
                    <td>${author.biography}</td>
                    <td>
                        <button onclick="editAuthor(${author.id}, '${author.first_name}', '${author.last_name}', '${author.biography}')">Edit</button>
                        <button onclick="deleteAuthor(${author.id})">Delete</button>
                    </td>
                `;
                authorsTableBody.appendChild(row);
                const option = document.createElement('option');
                option.value = author.id;
                option.text = `${author.first_name} ${author.last_name}`;
                authorSelect.appendChild(option);
            });
        });
}

function fetchBooks() {
    fetch('read_books.php')
        .then(response => response.json())
        .then(data => {
            const booksTableBody = document.getElementById('booksTable').querySelector('tbody');
            booksTableBody.innerHTML = '';
            data.forEach(book => {
                const row = document.createElement('tr');
                row.innerHTML = `
                    <td>${book.id}</td>
                    <td>${book.title}</td>
                    <td>${book.first_name} ${book.last_name}</td>
                    <td>${book.year}</td>
                    <td>${book.pages}</td>
                    <td><img src="${book.image_url}" alt="${book.title}" width="50"></td>
                    <td>${book.category_title}</td>
                    <td>
                        <button onclick="editBook(${book.id}, '${book.title}', ${book.author_id}, ${book.year}, ${book.pages}, '${book.image_url}', ${book.category_id})">Edit</button>
                        <button onclick="deleteBook(${book.id}, '${book.title}')">Delete</button>
                    </td>
                `;
                booksTableBody.appendChild(row);
            });
        });
}

function fetchCategories() {
    fetch('read_categories.php')
        .then(response => response.json())
        .then(data => {
            const categorySelect = document.getElementById('category_id');
            categorySelect.innerHTML = '';
            data.forEach(category => {
                const option = document.createElement('option');
                option.value = category.id;
                option.text = category.title;
                categorySelect.appendChild(option);
            });
        });
}

function createAuthor() {
    const first_name = document.getElementById('first_name').value;
    const last_name = document.getElementById('last_name').value;
    const biography = document.getElementById('biography').value;
    const formData = new FormData();
    formData.append('first_name', first_name);
    formData.append('last_name', last_name);
    formData.append('biography', biography);

    fetch('create_author.php', {
        method: 'POST',
        body: formData
    })
    .then(response => response.text())
    .then(data => {
        alert(data);
        fetchAuthors();
    });
}

function editAuthor(id, first_name, last_name, biography) {
    const newFirstName = prompt('Edit First Name:', first_name);
    const newLastName = prompt('Edit Last Name:', last_name);
    const newBiography = prompt('Edit Biography:', biography);
    if (newFirstName !== null && newLastName !== null && newBiography !== null && newBiography.length >= 20) {
        const formData = new FormData();
        formData.append('id', id);
        formData.append('first_name', newFirstName);
        formData.append('last_name', newLastName);
        formData.append('biography', newBiography);

        fetch('update_author.php', {
            method: 'POST',
            body: formData
        })
        .then(response => response.text())
        .then(data => {
            alert(data);
            fetchAuthors();
        });
    } else {
        alert("Biography must be at least 20 characters long.");
    }
}

function deleteAuthor(id) {
    if (confirm('Are you sure you want to delete this author?')) {
        const formData = new FormData();
        formData.append('id', id);

        fetch('delete_author.php', {
            method: 'POST',
            body: formData
        })
        .then(response => response.text())
        .then(data => {
            alert(data);
            fetchAuthors();
        });
    }
}

function createBook() {
    const title = document.getElementById('title').value;
    const author_id = document.getElementById('author_id').value;
    const year = document.getElementById('year').value;
    const pages = document.getElementById('pages').value;
    const image_url = document.getElementById('image_url').value;
    const category_id = document.getElementById('category_id').value;
    const formData = new FormData();
    formData.append('title', title);
    formData.append('author_id', author_id);
    formData.append('year', year);
    formData.append('pages', pages);
    formData.append('image_url', image_url);
    formData.append('category_id', category_id);

    fetch('create_book.php', {
        method: 'POST',
        body: formData
    })
    .then(response => response.text())
    .then(data => {
        alert(data);
        fetchBooks();
    });
}

function editBook(id, title, author_id, year, pages, image_url, category_id) {
    const newTitle = prompt('Edit Title:', title);
    const newAuthorId = prompt('Edit Author ID:', author_id);
    const newYear = prompt('Edit Year:', year);
    const newPages = prompt('Edit Pages:', pages);
    const newImageUrl = prompt('Edit Image URL:', image_url);
    const newCategoryId = prompt('Edit Category ID:', category_id);
    if (newTitle !== null && newAuthorId !== null && newYear !== null && newPages !== null && newImageUrl !== null && newCategoryId !== null) {
        const formData = new FormData();
        formData.append('id', id);
        formData.append('title', newTitle);
        formData.append('author_id', newAuthorId);
        formData.append('year', newYear);
        formData.append('pages', newPages);
        formData.append('image_url', newImageUrl);
        formData.append('category_id', newCategoryId);

        fetch('update_book.php', {
            method: 'POST',
            body: formData
        })
        .then(response => response.text())
        .then(data => {
            alert(data);
            fetchBooks();
        });
    }
}

function deleteBook(id, title) {
    Swal.fire({
        title: 'Are you sure?',
        text: `Deleting the book "${title}" will remove all comments and notes associated with it.`,
        icon: 'warning',
        showCancelButton: true,
        confirmButtonText: 'Yes, delete it!',
        cancelButtonText: 'No, cancel'
    }).then((result) => {
        if (result.isConfirmed) {
            const formData = new FormData();
            formData.append('id', id);

            fetch('delete_book.php', {
                method: 'POST',
                body: formData
            })
            .then(response => response.text())
            .then(data => {
                alert(data);
                fetchBooks();
            });
        }
    });
}
