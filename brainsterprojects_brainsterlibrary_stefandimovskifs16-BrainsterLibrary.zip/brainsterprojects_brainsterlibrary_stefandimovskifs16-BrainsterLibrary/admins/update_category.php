<?php
include 'db.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $id = $_POST['id'];
    $title = $_POST['title'];

    $sql = "UPDATE categories SET title='$title' WHERE id=$id";
    if (mysqli_query($conn, $sql)) {
        echo "Category updated successfully";
    } else {
        echo "Error: " . $sql . "<br>" . mysqli_error($conn);
    }
}
?>
