<?php
include 'db.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $title = $_POST['title'];
    $author_id = $_POST['author_id'];
    $year = $_POST['year'];
    $pages = $_POST['pages'];
    $image_url = $_POST['image_url'];
    $category_id = $_POST['category_id'];

    $sql = "INSERT INTO books (title, author_id, year, pages, image_url, category_id) VALUES ('$title', $author_id, $year, $pages, '$image_url', $category_id)";
    if (mysqli_query($conn, $sql)) {
        echo "New book created successfully";
    } else {
        echo "Error: " . $sql . "<br>" . mysqli_error($conn);
    }
}
?>
