<?php
include 'db.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $title = $_POST['title'];

    $sql = "INSERT INTO categories (title) VALUES ('$title')";
    if (mysqli_query($conn, $sql)) {
        echo "New category created successfully";
    } else {
        echo "Error: " . $sql . "<br>" . mysqli_error($conn);
    }
}
?>
