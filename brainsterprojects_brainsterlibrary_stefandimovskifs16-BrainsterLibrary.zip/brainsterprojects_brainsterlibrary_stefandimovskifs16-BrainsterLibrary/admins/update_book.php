<?php
include 'db.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $id = $_POST['id'];
    $title = $_POST['title'];
    $author_id = $_POST['author_id'];
    $year = $_POST['year'];
    $pages = $_POST['pages'];
    $image_url = $_POST['image_url'];
    $category_id = $_POST['category_id'];

    $sql = "UPDATE books SET title='$title', author_id=$author_id, year=$year, pages=$pages, image_url='$image_url', category_id=$category_id WHERE id=$id";
    if (mysqli_query($conn, $sql)) {
        echo "Book updated successfully";
    } else {
        echo "Error: " . $sql . "<br>" . mysqli_error($conn);
    }
}
?>
