<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    echo "You need to be logged in to add a note.";
    exit;
}

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "brainster_library";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$user_id = $_SESSION['user_id'];
$book_id = $_POST['book_id'];
$note = $_POST['note'];

$sql = "INSERT INTO notes (user_id, book_id, note) VALUES (?, ?, ?)";
$stmt = $conn->prepare($sql);
$stmt->bind_param("iis", $user_id, $book_id, $note);

if ($stmt->execute()) {
    echo "Note added.";
} else {
    echo "Error: " . $stmt->error;
}

$stmt->close();
$conn->close();
?>
