<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Brainster Library - Admin</title>
    <link rel="stylesheet" href="styless.css">

    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

    <style>
        .btn {
            cursor: pointer;
            text-decoration: none;
            color: black;
            margin-right: 35px;
            background-color: red;
            padding: 8px 10px;
            border: red 1px solid;
            border-radius: 5px;
        }

        input {
            padding: 10px;
            border-radius: 2px;
        }

        select {
            padding: 10px;
            border-radius: 2px;
        }
    </style>
</head>

<a class="btn" href="category.html">Create Category</a>
<a class="btn" href="comments.php">Appruve comments</a>
<a class="btn" href="logout.php">Logout</a>


<body>
    <h1>Manage Authors</h1>
    <form id="createAuthorForm">
        <input type="text" id="first_name" name="first_name" placeholder="First Name" required>
        <input type="text" id="last_name" name="last_name" placeholder="Last Name" required>
        <textarea id="biography" name="biography" placeholder="Biography (min 20 characters)" required></textarea>
        <button class="btn" type="submit">Create Author</button>
    </form>

    <h2>Authors List</h2>
    <table id="authorsTable">
        <thead>
            <tr>
                <th>ID</th>
                <th>First Name</th>
                <th>Last Name</th>
                <th>Biography</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
        </tbody>
    </table>

    <h1>Manage Books</h1>
    <form id="createBookForm">
        <input type="text" id="title" name="title" placeholder="Title" required>
        <select id="author_id" name="author_id" required>
            <option value="1">1</option>
            <option value="2">2</option>
            <option value="3">3</option>
        </select>
        <input type="number" id="year" name="year" placeholder="Year" required>
        <input type="number" id="pages" name="pages" placeholder="Pages" required>
        <input type="url" id="image_url" name="image_url" placeholder="Image URL" required>


        <select id="category_id" name="category_id" required>
            <option value="1">1</option>
            <option value="2">2</option>
            <option value="3">3</option>

        </select>




        <button class="btn" type="submit">Create Book</button>
    </form>




    <h2>Books List</h2>
    <table id="booksTable">
        <thead>
            <tr>
                <th>ID</th>
                <th>Title</th>
                <th>Author</th>
                <th>Year</th>
                <th>Pages</th>
                <th>Image</th>
                <th>Category</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
        </tbody>
    </table>



    <script src="scripts.js"></script>

</body>

</html>