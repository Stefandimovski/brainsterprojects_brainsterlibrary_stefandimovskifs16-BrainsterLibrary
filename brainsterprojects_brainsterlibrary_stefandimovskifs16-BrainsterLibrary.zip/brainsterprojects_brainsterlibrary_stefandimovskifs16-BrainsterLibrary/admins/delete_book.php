<?php
include 'db.php';


if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $id = $_POST['id'];

    $sql = "UPDATE books SET deleted_at=NOW() WHERE id=$id";
    if (mysqli_query($conn, $sql)) {
        echo "Author deleted successfully";
    } else {
        echo "Error: " . $sql . "<br>" . mysqli_error($conn);
    }
}
