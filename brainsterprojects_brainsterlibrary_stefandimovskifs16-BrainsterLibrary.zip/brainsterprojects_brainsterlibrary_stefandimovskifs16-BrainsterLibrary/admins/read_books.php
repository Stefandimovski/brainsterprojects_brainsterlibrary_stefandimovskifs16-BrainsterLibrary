<?php
include 'db.php';

$sql = "SELECT books.*, authors.first_name, authors.last_name, categories.title as category_title FROM books 
        JOIN authors ON books.author_id = authors.id
        JOIN categories ON books.category_id = categories.id
        WHERE books.deleted_at IS NULL";
$result = mysqli_query($conn, $sql);

$books = [];
while($row = mysqli_fetch_assoc($result)) {
    $books[] = $row;
}

echo json_encode($books);
?>
