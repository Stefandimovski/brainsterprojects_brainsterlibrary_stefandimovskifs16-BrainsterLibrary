<?php
include 'db.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $id = $_POST['id'];
    $first_name = $_POST['first_name'];
    $last_name = $_POST['last_name'];
    $biography = $_POST['biography'];

    if (strlen($biography) < 20) {
        echo "Biography must be at least 20 characters long.";
    } else {
        $sql = "UPDATE authors SET first_name='$first_name', last_name='$last_name', biography='$biography' WHERE id=$id";
        if (mysqli_query($conn, $sql)) {
            echo "Author updated successfully";
        } else {
            echo "Error: " . $sql . "<br>" . mysqli_error($conn);
        }
    }
}
?>
