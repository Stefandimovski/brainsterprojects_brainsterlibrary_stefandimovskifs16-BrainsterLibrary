<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "brainster_library";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$bookId = $_GET['id'];

$sql = "SELECT b.id, b.title, b.year, b.pages, b.image_url, a.first_name, a.last_name, a.biography, c.title AS category_title 
        FROM books b 
        JOIN authors a ON b.author_id = a.id 
        JOIN categories c ON b.category_id = c.id 
        WHERE b.id = $bookId";

$result = $conn->query($sql);
$book = null;

if ($result->num_rows > 0) {
    $book = $result->fetch_assoc();
}

$sql = "SELECT u.username, c.comment 
        FROM comments c 
        JOIN users u ON c.user_id = u.id 
        WHERE c.book_id = $bookId AND c.approved = 1";

$commentsResult = $conn->query($sql);
$comments = [];

if ($commentsResult->num_rows > 0) {
    while ($row = $commentsResult->fetch_assoc()) {
        $comments[] = $row;
    }
}

$conn->close();
echo json_encode(['book' => $book, 'comments' => $comments]);
