<?php
session_start();
require 'db.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = $_POST['username'];
    $password = $_POST['password'];

    $sql = "SELECT id, username, password, role FROM users WHERE username = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param('s', $username);
    $stmt->execute();
    $stmt->store_result();

    if ($stmt->num_rows > 0) {
        $stmt->bind_result($id, $username, $hashed_password, $role);
        $stmt->fetch();

        if (password_verify($password, $hashed_password)) {
            $_SESSION['user_id'] = $id;
            $_SESSION['username'] = $username;
            $_SESSION['role'] = $role;

            header('Location: index.html');
            exit();
        } else {
            $error = "Невалидно корисничко име или лозинка.";
        }
    } else {
        $error = "Невалидно корисничко име или лозинка.";
    }

    $stmt->close();
}

$conn->close();
?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>Најавување - Brainster Library</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <style>
        .login-container {
            margin-top: 100px;
            width: 300px;
        }
    </style>
</head>

<body>
    <div class="container">
        <div class="login-container mx-auto">
            <h2 class="text-center">Најавување</h2>
            <form action="login.php" method="POST">
                <div class="form-group">
                    <label for="username">Корисничко име</label>
                    <input type="text" class="form-control" id="username" name="username" required>
                </div>
                <div class="form-group">
                    <label for="password">Лозинка</label>
                    <input type="password" class="form-control" id="password" name="password" required>
                </div>
                <button type="submit" class="btn btn-primary btn-block">Најави се</button>
                <?php if (isset($error)) : ?>
                    <div class="alert alert-danger mt-2"><?php echo $error; ?></div>
                <?php endif; ?>
            </form>
            <div class="text-center mt-3">
                <a href="register.php">Регистрирај се</a>
            </div>
        </div>
    </div>
</body>

</html>