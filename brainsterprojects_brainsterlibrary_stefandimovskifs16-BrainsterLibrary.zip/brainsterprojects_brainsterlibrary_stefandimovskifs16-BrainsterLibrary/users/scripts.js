document.addEventListener('DOMContentLoaded', function() {
    fetchCategories();
    fetchBooks();

    document.getElementById('filterForm').addEventListener('submit', function(e) {
        e.preventDefault();
        filterBooks();
    });
});

function fetchCategories() {
    fetch('fetch_categories.php')
        .then(response => response.json())
        .then(data => {
            const categoriesContainer = document.getElementById('categories');
            data.forEach(category => {
                const checkbox = document.createElement('input');
                checkbox.type = 'checkbox';
                checkbox.id = 'category_' + category.id;
                checkbox.value = category.id;

                const label = document.createElement('label');
                label.htmlFor = 'category_' + category.id;
                label.textContent = category.title;

                const div = document.createElement('div');
                div.classList.add('inline-checkbox');
                div.appendChild(checkbox);
                div.appendChild(label);

                categoriesContainer.appendChild(div);
            });
        });
}

function fetchBooks() {
    fetch('fetch_books.php')
        .then(response => response.json())
        .then(data => {
            displayBooks(data);
        });
}

function filterBooks() {
    const checkboxes = document.querySelectorAll('#categories input[type="checkbox"]');
    const selectedCategories = Array.from(checkboxes)
                                    .filter(checkbox => checkbox.checked)
                                    .map(checkbox => checkbox.value);
    const url = 'fetch_books.php?categories=' + selectedCategories.join(',');
    fetch(url)
        .then(response => response.json())
        .then(data => {
            displayBooks(data);
        });
}

function displayBooks(data) {
}

fetchCategories();

function displayBooks(books) {
    const booksContainer = document.getElementById('booksContainer');
    booksContainer.innerHTML = '';
    books.forEach(book => {
        const bookCard = document.createElement('div');
        bookCard.className = 'book-card';
        bookCard.innerHTML = `
            <img src="${book.image_url}" alt="${book.title}">
            <h3>${book.title}</h3>
            <p>Author: ${book.first_name} ${book.last_name}</p>
            <p>Category: ${book.category_title}</p>
        `;
        bookCard.addEventListener('click', () => {
            window.location.href = `book_details.php?id=${book.id}`;
        });
        booksContainer.appendChild(bookCard);
    });
}


