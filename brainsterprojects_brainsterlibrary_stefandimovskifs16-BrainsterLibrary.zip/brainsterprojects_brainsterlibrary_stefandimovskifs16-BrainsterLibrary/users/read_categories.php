<?php
include 'db.php';

$sql = "SELECT * FROM categories WHERE deleted_at IS NULL";
$result = mysqli_query($conn, $sql);

$categories = [];
while ($row = mysqli_fetch_assoc($result)) {
    $categories[] = $row;
}

echo json_encode($categories);
