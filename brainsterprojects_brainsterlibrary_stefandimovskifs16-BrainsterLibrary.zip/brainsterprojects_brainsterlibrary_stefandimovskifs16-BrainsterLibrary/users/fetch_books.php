<?php

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "brainster_library";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}


$categoryFilter = "";
if (isset($_GET['categories']) && !empty($_GET['categories'])) {
    $categories = explode(',', $_GET['categories']);
    $categoryFilter = " AND c.id IN (" . implode(',', array_map('intval', $categories)) . ")";
}



$sql = "SELECT b.id, b.title, b.year, b.pages, b.image_url, a.first_name, a.last_name, c.title AS category_title
FROM books b
JOIN authors a ON b.author_id = a.id
JOIN categories c ON b.category_id = c.id
WHERE b.deleted_at IS NULL" . $categoryFilter;

$result = $conn->query($sql);
$books = [];

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $books[] = $row;
    }
}

$conn->close();
echo json_encode($books);
