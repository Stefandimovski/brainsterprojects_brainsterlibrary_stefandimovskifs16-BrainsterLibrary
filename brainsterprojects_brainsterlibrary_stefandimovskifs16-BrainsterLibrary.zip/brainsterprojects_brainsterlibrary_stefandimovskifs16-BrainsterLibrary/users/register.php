<?php
require 'db.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = $_POST['username'];
    $password = $_POST['password'];
    $confirm_password = $_POST['confirm_password'];

    if ($password != $confirm_password) {
        $error = "Лозинките не се совпаѓаат.";
    } else {
        $sql = "SELECT id FROM users WHERE username = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param('s', $username);
        $stmt->execute();
        $stmt->store_result();

        if ($stmt->num_rows > 0) {
            $error = "Корисничкото име е веќе зафатено.";
        } else {
            $hashed_password = password_hash($password, PASSWORD_DEFAULT);
            $sql = "INSERT INTO users (username, password, role) VALUES (?, ?, 'user')";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param('ss', $username, $hashed_password);

            if ($stmt->execute()) {
                $success = "Успешно се регистриравте. Можете да се најавите.";
            } else {
                $error = "Настана грешка при регистрацијата. Обидете се повторно.";
            }
        }
        $stmt->close();
    }
}

$conn->close();
?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>Регистрација - Brainster Library</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <style>
        .register-container {
            margin-top: 100px;
            width: 400px;
        }
    </style>
</head>

<body>
    <div class="container">
        <div class="register-container mx-auto">
            <h2 class="text-center">Регистрација</h2>
            <form action="register.php" method="POST">
                <div class="form-group">
                    <label for="username">Корисничко име</label>
                    <input type="text" class="form-control" id="username" name="username" required>
                </div>
                <div class="form-group">
                    <label for="password">Лозинка</label>
                    <input type="password" class="form-control" id="password" name="password" required>
                </div>
                <div class="form-group">
                    <label for="confirm_password">Потврди лозинка</label>
                    <input type="password" class="form-control" id="confirm_password" name="confirm_password" required>
                </div>
                <button type="submit" class="btn btn-primary btn-block">Регистрирај се</button>
                <?php if (isset($error)) : ?>
                    <div class="alert alert-danger mt-2"><?php echo $error; ?></div>
                <?php elseif (isset($success)) : ?>
                    <div class="alert alert-success mt-2"><?php echo $success; ?></div>
                <?php endif; ?>
            </form>
            <div class="text-center mt-3">
                <a href="login.php">Најави се</a>
            </div>
        </div>
    </div>
</body>

</html>