document.addEventListener('DOMContentLoaded', function() {
    const urlParams = new URLSearchParams(window.location.search);
    const bookId = urlParams.get('id');
    if (bookId) {
        fetchBookDetails(bookId);
        fetchComments(bookId);
        fetchNotes(bookId);
    }
});

function fetchBookDetails(bookId) {
    fetch(`fetch_book_details.php?id=${bookId}`)
        .then(response => response.json())
        .then(data => {
            displayBookDetails(data.book, data.comments);
        });
}

function displayBookDetails(book, comments) {
    const bookDetails = document.getElementById('bookDetails');
    bookDetails.innerHTML = `
        <h1>${book.title}</h1>
        <img src="${book.image_url}" alt="${book.title}">
        <p>Author: ${book.first_name} ${book.last_name}</p>
        <p>Biography: ${book.biography}</p>
        <p>Year: ${book.year}</p>
        <p>Pages: ${book.pages}</p>
        <p>Category: ${book.category_title}</p>
    `;
}

function fetchComments(bookId) {
    fetch(`fetch_comments.php?book_id=${bookId}`)
        .then(response => response.json())
        .then(comments => {
            displayComments(comments);
        });
}

function displayComments(comments) {
    const commentsContainer = document.getElementById('comments');
    commentsContainer.innerHTML = '';
    comments.forEach(comment => {
        const commentElement = document.createElement('p');
        commentElement.innerHTML = `<strong>${comment.username}:</strong> ${comment.comment}`;
        commentsContainer.appendChild(commentElement);
    });
}

function submitComment() {
    const urlParams = new URLSearchParams(window.location.search);
    const bookId = urlParams.get('id');
    const commentText = document.getElementById('commentText').value;

    fetch('submit_comment.php', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded',
        },
        body: `book_id=${bookId}&comment=${commentText}`
    })
    .then(response => response.text())
    .then(message => {
        alert(message);
        fetchComments(bookId);
    });
}

function fetchNotes(bookId) {
    fetch(`fetch_notes.php?book_id=${bookId}`)
        .then(response => response.json())
        .then(notes => {
            displayNotes(notes);
        });
}

function displayNotes(notes) {
    const notesContainer = document.getElementById('notes');
    notesContainer.innerHTML = '';
    notes.forEach(note => {
        const noteElement = document.createElement('p');
        noteElement.innerHTML = `<strong>${note.note}</strong> <button onclick="deleteNote(${note.id})">Delete</button>`;
        notesContainer.appendChild(noteElement);
    });
}

function submitNote() {
    const urlParams = new URLSearchParams(window.location.search);
    const bookId = urlParams.get('id');
    const noteText = document.getElementById('noteText').value;

    fetch('submit_note.php', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded',
        },
        body: `book_id=${bookId}&note=${noteText}`
    })
    .then(response => response.text())
    .then(message => {
        alert(message);
        fetchNotes(bookId);
    });
}

function deleteNote(noteId) {
    fetch('delete_note.php', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded',
        },
        body: `note_id=${noteId}`
    })
    .then(response => response.text())
    .then(message => {
        alert(message);
        const urlParams = new URLSearchParams(window.location.search);
        const bookId = urlParams.get('id');
        fetchNotes(bookId);
    });
}
