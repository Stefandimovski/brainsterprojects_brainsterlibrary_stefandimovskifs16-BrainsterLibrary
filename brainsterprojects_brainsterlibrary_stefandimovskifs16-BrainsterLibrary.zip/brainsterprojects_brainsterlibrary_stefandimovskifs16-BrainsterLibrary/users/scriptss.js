document.addEventListener('DOMContentLoaded', function() {
    const urlParams = new URLSearchParams(window.location.search);
    const bookId = urlParams.get('id');
    if (bookId) {
        fetchBookDetails(bookId);
    }
});

function fetchBookDetails(bookId) {
    fetch(`fetch_book_details.php?id=${bookId}`)
        .then(response => {
            console.log('Response status:', response.status);
            console.log('Response headers:', [...response.headers]);
            if (!response.ok) {
                throw new Error('Network response was not ok');
            }
            return response.text(); 
        })
        .then(text => {
            console.log('Raw response:', text); 
            try {
                return JSON.parse(text); 
            } catch (error) {
                console.error('Error parsing JSON:', error);
                throw new Error('Failed to parse JSON');
            }
        })
        .then(data => {
            displayBookDetails(data.book, data.comments);
        })
        .catch(error => {
            console.error('There was a problem with the fetch operation:', error);
            displayError();
        });
}


function displayBookDetails(book, comments) {
    const bookDetails = document.getElementById('bookDetails');

    bookDetails.innerHTML = `
        <div class="book-container">
            <h1 class="book-title">${book.title}</h1>
            <img class="book-image" src="${book.image_url}" alt="${book.title}">
            <p class="book-author"><strong>Author:</strong> ${book.first_name} ${book.last_name}</p>
            <p class="book-author"><strong>Biography: ${book.biography}</p>
            <p class="book-year"><strong>Year:</strong> ${book.year}</p>
            <p class="book-pages"><strong>Pages:</strong> ${book.pages}</p>
            <p class="book-category"><strong>Category:</strong> ${book.category_title}</p>
            <h2 class="comments-title">Comments</h2>
            <div id="comments" class="comments-section">
                ${comments.map(comment => `<p class="comment"><strong>${comment.username}:</strong> ${comment.comment}</p>`).join('')}
            </div>          
        </div>
    `;

}

function displayError() {
    const bookDetails = document.getElementById('bookDetails');
    bookDetails.innerHTML = `
        <p>Sorry, we couldn't fetch the book details at the moment. Please try again later.</p>
    `;
}
