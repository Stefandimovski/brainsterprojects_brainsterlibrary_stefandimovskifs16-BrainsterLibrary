<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Book Details</title>
    <link rel="stylesheet" href="book.css">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>


    <style>
        .btn {
            cursor: pointer;
            text-decoration: none;
            color: darkslategray;
            margin-right: 35px;
            background-color: red;
            padding: 8px 10px;
            border: red 1px solid;
            border-radius: 5px;

        }

        .footer {
            z-index: 2;
            padding: 20px;
            color: white;
            text-align: center;
            background-color: rgb(52, 49, 49);
        }

        .navbar {
            background-color: #FFD700;
            width: 100%;
            box-shadow: 5px 2px 5px 5px rgba(50, 50, 50, .1);
            z-index: 1;
        }

        .nav {
            display: flex;
            align-items: center;
            width: 90%;
            margin-right: auto;
            margin-left: auto;
            padding-top: 15px;
            padding-bottom: 15px;
        }

        .nav a {
            text-decoration: none;
            font-size: 15px;
            font-weight: 700;
            color: black;
        }

        .comm {
            margin-left: 50px;
            margin-bottom: 50px;
        }

        textarea {
            border-radius: 5px;
        }
    </style>
</head>

<body>


    <header class="navbar">
        <div class="nav">
            <a class="btn" href="index.html">Back</a>
            <h1>Book Catalog</h1>
        </div>

    </header>

    <div id="bookDetails">
    </div>



    <div id="bookDetails">
    </div>

    <div class="comm" id="commentSection">
        <h2>Comments</h2>
        <div id="comments">
        </div>
        <div id="commentForm">
            <textarea id="commentText" placeholder="Leave a comment..."></textarea>
            <button onclick="submitComment()">Submit</button>
        </div>
    </div>

    <div class="comm" id="notesSection">
        <h2>Private Notes</h2>
        <div id="notes">
        </div>
        <div id="noteForm">
            <textarea id="noteText" placeholder="Add a private note..."></textarea>
            <button onclick="submitNote()">Add Note</button>
        </div>
    </div>




    <div class="container mt-5">

        <footer class="footer">
            <div class="quote">
                <h3>Wise Thoughts</h3>
                <p id="quote-text"></p>
                <p id="quote-author"></p>
            </div>
        </footer>
    </div>

    <script>
        function fetchQuote() {
            $.ajax({
                url: 'http://api.quotable.io/random',
                method: 'GET',
                success: function(response) {
                    $('#quote-text').text('"' + response.content + '"');
                    $('#quote-author').text('- ' + response.author);
                }
            });
        }

        $(document).ready(function() {
            fetchQuote();
        });
    </script>

    <script src="scripta.js"></script>

    <script src="scriptss.js"></script>



</body>

</html>