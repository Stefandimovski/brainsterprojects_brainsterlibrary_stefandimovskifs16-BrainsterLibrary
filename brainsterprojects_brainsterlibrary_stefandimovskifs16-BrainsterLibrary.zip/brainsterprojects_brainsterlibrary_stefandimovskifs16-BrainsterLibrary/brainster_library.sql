-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 22, 2024 at 11:42 PM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `brainster_library`
--

-- --------------------------------------------------------

--
-- Table structure for table `admins`
--

CREATE TABLE `admins` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `role` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `admins`
--

INSERT INTO `admins` (`id`, `username`, `password`, `created_at`, `role`) VALUES
(1, 'pero', '$2y$10$UaeYjrnSItMSIEAHdi.qyO8iTU9FMq2jENOPcUpL1abkllpIYDl62', '2024-06-21 08:17:13', 'user'),
(2, 'dane', '$2y$10$0fBpRvlnzTHwgot14tpCN.W6ZQaU.zNWsIdqmLFDm6DI8DK9qExUu', '2024-06-21 08:18:12', 'user');

-- --------------------------------------------------------

--
-- Table structure for table `authors`
--

CREATE TABLE `authors` (
  `id` int(11) NOT NULL,
  `first_name` varchar(255) NOT NULL,
  `last_name` varchar(255) NOT NULL,
  `biography` text NOT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `authors`
--

INSERT INTO `authors` (`id`, `first_name`, `last_name`, `biography`, `deleted_at`) VALUES
(1, 'sdd', 'hhhh', 'jgfhgnvjhbkmnbhjkjbhjn', '2024-06-09 20:58:32'),
(2, 'caci1', 'delova', 'slavica delova dimovska cici buci', '2024-06-19 21:01:24'),
(3, 'seteff', 'dimm', 'wkughdskjvnvc vmjggfbn', '2024-06-21 15:00:54'),
(4, 'andrej', 'delov', 'fhdkjfdskfhdsfhdsfhdsfhsdj', NULL),
(5, 'alek1', 'sandar', 'gdgdgdgdfdfsfsfsfsfs', '2024-06-22 18:33:04'),
(6, 'petar', 'petkov', 'fjndsjgdsndsv ndsvdsvdsv', '2024-06-22 21:36:37'),
(7, 'dino', 'markov', 'duhfdskgjhsdkjfsdsgsddgsd', NULL),
(8, 'biskvit', 'delov', 'hasfksjkdhfdskjhgsdjfsddgdf', NULL),
(9, 'cuci', 'buci', 'jdfhsdfsdfsdfsddjkfnsdjfsh', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `books`
--

CREATE TABLE `books` (
  `id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `author_id` int(11) NOT NULL,
  `year` int(11) NOT NULL,
  `pages` int(11) NOT NULL,
  `image_url` varchar(255) NOT NULL,
  `category_id` int(11) NOT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `books`
--

INSERT INTO `books` (`id`, `title`, `author_id`, `year`, `pages`, `image_url`, `category_id`, `deleted_at`) VALUES
(1, 'stfan', 1, 1989, 155, 'https://images.pexels.com/photos/19254459/pexels-photo-19254459/free-photo-of-elegant-couple-walking-on-the-pavement-in-city.jpeg', 1, '2024-06-19 22:12:51'),
(3, 'stefan1', 1, 1990, 155, 'https://images.pexels.com/photos/19254459/pexels-photo-19254459/free-photo-of-elegant-couple-walking-on-the-pavement-in-city.jpeg', 1, '2024-06-19 22:27:01'),
(4, 'slavica1', 2, 1899, 25, 'https://images.pexels.com/photos/22944577/pexels-photo-22944577/free-photo-of-black-and-white-photo-of-palm-trees-on-the-beach.jpeg', 1, NULL),
(5, 'gigmigi', 2, 1983, 28, 'https://images.pexels.com/photos/21403982/pexels-photo-21403982/free-photo-of-black-and-white-photograph-of-flowers-in-a-vase.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2', 2, '2024-06-19 22:25:59'),
(6, 'vojna i mior', 3, 1812, 250, 'https://images.pexels.com/photos/4448847/pexels-photo-4448847.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2', 2, '2024-06-22 18:26:26'),
(7, 'anglija', 4, 1986, 158, 'https://images.pexels.com/photos/19174731/pexels-photo-19174731/free-photo-of-frozen-water-surface.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2', 2, '2024-06-21 15:00:43'),
(13, 'piwi99', 2, 1589, 258, 'https://images.pexels.com/photos/25358063/pexels-photo-25358063/free-photo-of-singapore-flyer.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2', 2, NULL),
(15, 'martin', 4, 1598, 125, 'https://images.pexels.com/photos/24879566/pexels-photo-24879566/free-photo-of-a-mountain-with-green-grass-and-rocks.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2', 4, '2024-06-20 16:23:01'),
(16, 'martince', 3, 1598, 125, 'https://images.pexels.com/photos/24879566/pexels-photo-24879566/free-photo-of-a-mountain-with-green-grass-and-rocks.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2', 6, NULL),
(17, 'martin125', 4, 1598, 125, 'https://images.pexels.com/photos/24879566/pexels-photo-24879566/free-photo-of-a-mountain-with-green-grass-and-rocks.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2', 6, '2024-06-21 18:23:23'),
(18, 'sumite', 7, 1987, 158, 'https://images.pexels.com/photos/15088908/pexels-photo-15088908/free-photo-of-a-shadow-of-a-person-on-a-white-curtain.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2', 12, NULL),
(19, 'farmer boy', 8, 2024, 155, 'https://images.pexels.com/photos/19802887/pexels-photo-19802887/free-photo-of-power-cables-on-a-railway.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2', 13, NULL),
(20, 'pirej', 9, 2586, 148, 'https://images.pexels.com/photos/15301144/pexels-photo-15301144/free-photo-of-foamy-waves-on-the-shore-and-skyscrapers-of-a-coastal-city-in-distance.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2', 9, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`id`, `title`, `deleted_at`) VALUES
(1, 'caci', '2024-06-10 20:32:35'),
(2, 'saab', '2024-06-15 16:46:14'),
(4, 'saab', '2024-06-21 15:02:55'),
(5, 'djezi1', '2024-06-22 19:50:13'),
(6, 'horori', NULL),
(9, 'sifi', '2024-06-22 21:37:12'),
(12, 'western', NULL),
(13, 'akcija', NULL),
(14, 'komedija', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `comments`
--

CREATE TABLE `comments` (
  `id` int(11) NOT NULL,
  `book_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `content` text NOT NULL,
  `approved` tinyint(1) DEFAULT 0,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `comment` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `comments`
--

INSERT INTO `comments` (`id`, `book_id`, `user_id`, `content`, `approved`, `deleted_at`, `comment`) VALUES
(7, 5, 1, '', 1, NULL, 'kdjvfjfkgrgrt'),
(8, 4, 3, '', 1, NULL, 'khgkjhlklkjkjk'),
(9, 4, 3, '', 1, NULL, 'lgsdlkgjsdkgmdsgsd'),
(10, 1, 3, '', 1, NULL, 'ljsdnglksdgdflkgmdfgdf'),
(11, 4, 1, '', 1, NULL, 'jas i ti sme'),
(12, 4, 1, '', 0, NULL, 'dhdhfdhghghgf'),
(13, 7, 5, '', 1, NULL, 'lksgjslgjglkew'),
(14, 17, 5, '', 1, NULL, 'lgsdgsg'),
(15, 3, 1, '', 0, NULL, 'ljdfsdgksdjgskd'),
(18, 4, 1, '', 0, NULL, 'gdsgsdgsdsdfasfasdas'),
(19, 4, 1, '', 0, NULL, 'dsgsgsdgs'),
(20, 4, 1, '', 0, NULL, 'gfgdfdfgf'),
(21, 7, 1, '', 1, NULL, 'hgkhhbjnm'),
(22, 5, 1, '', 1, NULL, 'jhgdsfsjsfjk'),
(23, 5, 1, '', 1, NULL, 'dgdgsdfgs'),
(24, 18, 1, '', 1, NULL, 'te molam raboti'),
(25, 18, 1, '', 1, NULL, 'super kniga'),
(27, 6, 5, '', 1, NULL, 'gcghcjcvbvhvgjhkjhlj'),
(29, 13, 1, '', 0, NULL, 'vrteleska'),
(30, 16, 4, '', 1, NULL, 'planina'),
(31, 19, 2, '', 0, NULL, 'mnogu dobro kuce'),
(32, 19, 1, '', 1, NULL, 'taka ti rekov'),
(33, 19, 1, '', 1, NULL, 'super kniga');

-- --------------------------------------------------------

--
-- Table structure for table `notes`
--

CREATE TABLE `notes` (
  `id` int(11) NOT NULL,
  `book_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `content` text NOT NULL,
  `note` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `notes`
--

INSERT INTO `notes` (`id`, `book_id`, `user_id`, `content`, `note`) VALUES
(1, 4, 1, '', 'dfhdffhfhfhd'),
(2, 5, 1, '', 'fhfhdhdfhghf'),
(3, 4, 1, '', 'jbkhbn,mn.'),
(4, 7, 1, '', 'jgj,m'),
(5, 6, 1, '', 'jhdlfsifleifefe'),
(6, 18, 1, '', 'fhdfhfdhfghgf');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `role` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `password`, `created_at`, `role`) VALUES
(1, 'stefan', '$2y$10$pYPycONScV4zFjCNY5h.HObfUAvLUmy2x/u0QwPUjekeZGP8w.D2O', '2024-06-13 20:42:46', NULL),
(3, 'alek', '$2y$10$q8vf7Vai//Odr.WwJ5Zw6.A.equ4eGhNpxq.ZYsJKh7vpDEmy.mcm', '2024-06-15 16:03:58', NULL),
(4, 'caci', '$2y$10$e0f1dvQFLSMZ2RJgn4kFAeY1riYs15IpiirawJ.qCYxvXY233TRPu', '2024-06-17 22:13:32', NULL),
(5, 'bobi', '$2y$10$9/gU2/wAXRptQlzOU1m0LOo.bLSo3Smx8.3nHmhdcuMMcoOJPVSWG', '2024-06-17 23:35:54', 'user');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admins`
--
ALTER TABLE `admins`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`);

--
-- Indexes for table `authors`
--
ALTER TABLE `authors`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `books`
--
ALTER TABLE `books`
  ADD PRIMARY KEY (`id`),
  ADD KEY `author_id` (`author_id`),
  ADD KEY `category_id` (`category_id`);

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `comments`
--
ALTER TABLE `comments`
  ADD PRIMARY KEY (`id`),
  ADD KEY `book_id` (`book_id`);

--
-- Indexes for table `notes`
--
ALTER TABLE `notes`
  ADD PRIMARY KEY (`id`),
  ADD KEY `book_id` (`book_id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admins`
--
ALTER TABLE `admins`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `authors`
--
ALTER TABLE `authors`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `books`
--
ALTER TABLE `books`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `comments`
--
ALTER TABLE `comments`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=34;

--
-- AUTO_INCREMENT for table `notes`
--
ALTER TABLE `notes`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `books`
--
ALTER TABLE `books`
  ADD CONSTRAINT `books_ibfk_1` FOREIGN KEY (`author_id`) REFERENCES `authors` (`id`),
  ADD CONSTRAINT `books_ibfk_2` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`);

--
-- Constraints for table `comments`
--
ALTER TABLE `comments`
  ADD CONSTRAINT `comments_ibfk_1` FOREIGN KEY (`book_id`) REFERENCES `books` (`id`);

--
-- Constraints for table `notes`
--
ALTER TABLE `notes`
  ADD CONSTRAINT `notes_ibfk_1` FOREIGN KEY (`book_id`) REFERENCES `books` (`id`),
  ADD CONSTRAINT `notes_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
